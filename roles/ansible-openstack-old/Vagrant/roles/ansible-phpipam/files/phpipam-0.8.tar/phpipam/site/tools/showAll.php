<h4><?php print _('phpIPAM tools'); ?></h4>
<hr>

<div class='alert alert-info alert-dash alert-absolute'><i class='icon-gray icon-chevron-left'></i> <?php print _('Please select tool from left menu!'); ?></div>