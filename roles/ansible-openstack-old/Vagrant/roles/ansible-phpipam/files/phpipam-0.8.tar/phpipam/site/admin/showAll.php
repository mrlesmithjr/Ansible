<h4><?php print _('phpIPAM server settings'); ?></h4>
<hr>

<div class='alert alert-info alert-dash alert-absolute'><i class='icon-gray icon-chevron-left'></i> <?php print _('Please select setting from left menu'); ?>!</div>